Reader data and methods
Why Build a Giant Table When You Only Need One Answer?
By Tin Ninkoviċ. Reader dataset edition 0.2.1.

Start with Methods and definitions.txt. The four CSV files contain retained historical observations, separate-method summaries, derived comparisons and mathematical representation counts. Their values are unchanged from reader dataset edition 0.2.0. No benchmark was rerun.

Reader file manifest.json and Checksums.txt identify only the files included in this public dataset. Implementation software is not included.
