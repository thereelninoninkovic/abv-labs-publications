Reader data for Why Build a Giant Table When You Only Need One Answer?
By Tin Ninkoviċ.

These files describe 25 paired historical observations, not a new benchmark. Start with Methods and definitions.txt. benchmark-comparison.csv adds explicitly derived changes between method medians. Raw source archives and implementation code are not included.
